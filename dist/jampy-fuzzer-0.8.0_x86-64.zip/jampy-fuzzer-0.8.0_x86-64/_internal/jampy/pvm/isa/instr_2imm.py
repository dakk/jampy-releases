# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from typing import List

from jampy.codec import i2b

from ..pvmstate import Memory
from ..utils import cast_8, cast_16, cast_32
from .instr import Instr, _decode_2imm, instr


@instr(30, "store_imm_u8", n_imm=2, decoder=_decode_2imm)
class InsStoreImmU8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        vx, vy = args
        mem[vx] = cast_8(vy)


@instr(31, "store_imm_u16", n_imm=2, decoder=_decode_2imm)
class InsStoreImmU16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        vx, vy = args
        mem.memcpy(vx, i2b(2, cast_16(vy)))


@instr(32, "store_imm_u32", n_imm=2, decoder=_decode_2imm)
class InsStoreImmU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        vx, vy = args
        mem.memcpy(vx, i2b(4, cast_32(vy)))


@instr(33, "store_imm_u64", n_imm=2, decoder=_decode_2imm)
class InsStoreImmU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        vx, vy = args
        mem.memcpy(vx, i2b(8, vy))


INSTR_2IMM_LIST = [InsStoreImmU8, InsStoreImmU16, InsStoreImmU32, InsStoreImmU64]
