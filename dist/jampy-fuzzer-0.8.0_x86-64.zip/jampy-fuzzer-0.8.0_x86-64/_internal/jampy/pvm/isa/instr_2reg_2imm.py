# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from typing import List

from ..pvmstate import Memory
from ..utils import cast_32
from .instr import Instr, _decode_2reg_2imm, instr


@instr(
    180,
    "load_imm_jump_ind",
    n_reg=2,
    n_imm=2,
    decoder=_decode_2reg_2imm,
    source_dest_regs=([1], [0]),
)
class InsLoadImmJumpInd(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx, vy = args

        res, pc = prog.djump(pc, cast_32(regs[rb] + vy % mem.size))
        regs[ra] = vx

        return res, None, pc


# $(0.8.0 - A.34)
INSTR_2REG_2IMM_LIST = [InsLoadImmJumpInd]
