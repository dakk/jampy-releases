# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


from typing import List

from ..pvmstate import Memory
from .instr import Instr, _decode_1off, instr


@instr(40, "jump", n_off=1, decoder=_decode_1off)
class InsJump(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        vx = args
        res, pc = prog.sjump(pc, vx % mem.size)

        return res, None, pc


INSTR_1OFF_LIST = [InsJump]
