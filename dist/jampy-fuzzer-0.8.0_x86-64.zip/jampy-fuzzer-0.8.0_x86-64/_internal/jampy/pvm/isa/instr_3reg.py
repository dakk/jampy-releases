# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from math import floor
from typing import List

from ..pvmstate import Memory
from ..utils import (
    bw_and,
    bw_and_inv,
    bw_or,
    bw_or_inv,
    bw_xnor,
    bw_xor,
    cast_32,
    cast_64,
    rot_l,
    rot_r,
    rtz,
    signed_extension_function,
    smod,
    zeta,
    zeta_inv,
)
from .instr import Instr, _decode_3reg, instr


@instr(190, "add_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsAdd32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = signed_extension_function(4, cast_32(regs[ra] + regs[rb]))


@instr(191, "sub_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsSub32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = signed_extension_function(
            4, cast_32(regs[ra] + 2**32 - cast_32(regs[rb]))
        )


@instr(192, "mul_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsMul32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = signed_extension_function(4, cast_32(regs[ra] * regs[rb]))


@instr(193, "div_u_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsDivU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args

        if cast_32(regs[rb]) == 0:
            res = 2**64 - 1
        else:
            res = signed_extension_function(
                4, floor(cast_32(regs[ra]) / cast_32(regs[rb]))
            )
        regs[rd] = res


@instr(194, "div_s_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsDivS32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        a = zeta(4, cast_32(regs[ra]))
        b = zeta(4, cast_32(regs[rb]))

        if b == 0:
            res = 2**64 - 1
        elif a == -(2**31) and b == -1:
            res = 2**64 + a  # Not sure, fixes overflow tests (a is negative)
        else:
            # This fixes a numerical problem on python divisions
            if a < 0 and b < 0:
                res = zeta_inv(8, rtz(abs(a) // abs(b)))
            elif a < 0 or b < 0:
                res = zeta_inv(8, rtz(-(abs(a) // abs(b))))
            else:
                res = zeta_inv(8, rtz(a // b))

        regs[rd] = res


@instr(195, "rem_u_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsRemU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args

        if cast_32(regs[rb]) == 0:
            res = signed_extension_function(4, cast_32(regs[ra]))
        else:
            res = signed_extension_function(4, cast_32(regs[ra]) % cast_32(regs[rb]))
        regs[rd] = res


@instr(196, "rem_s_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsRemS32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        a = zeta(4, cast_32(regs[ra]))
        b = zeta(4, cast_32(regs[rb]))

        if b == 0:
            res = zeta_inv(8, a)
        elif a == -(2**31) and b == -1:
            res = 0
        else:
            res = zeta_inv(8, smod(a, b))
        regs[rd] = res


@instr(197, "shlo_l_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsShloL32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = signed_extension_function(
            4, cast_32(regs[ra] * 2 ** (regs[rb] % 32))
        )


@instr(198, "shlo_r_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsShloR32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = signed_extension_function(
            4, floor(cast_32(regs[ra]) // 2 ** (regs[rb] % 32))
        )


@instr(199, "shar_r_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsSharR32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = zeta_inv(
            8, floor(zeta(4, cast_32(regs[ra])) // 2 ** (regs[rb] % 32))
        )


@instr(200, "add_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsAdd64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = cast_64(regs[ra] + regs[rb])


@instr(201, "sub_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsSub64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = cast_64(regs[ra] + 2**64 - regs[rb])


@instr(202, "mul_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsMul64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = cast_64(regs[ra] * regs[rb])


@instr(203, "div_u_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsDivU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args

        if regs[rb] == 0:
            res = 2**64 - 1
        else:
            res = regs[ra] // regs[rb]

        regs[rd] = res


@instr(204, "div_s_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsDivS64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        wa = regs[ra]
        wb = regs[rb]

        if wb == 0:
            res = 2**64 - 1
        elif zeta(8, wa) == -(2**63) and zeta(8, wb) == -1:
            res = wa
        else:
            zwa = zeta(8, wa)
            zwb = zeta(8, wb)
            # This fixes a numerical problem on python divisions
            if zwa < 0 and zwb < 0:
                res = zeta_inv(8, rtz(abs(zwa) // abs(zwb)))
            elif zwa < 0 or zwb < 0:
                res = zeta_inv(8, rtz(-(abs(zwa) // abs(zwb))))
            else:
                res = zeta_inv(8, rtz(zwa // zwb))

        regs[rd] = res


@instr(205, "rem_u_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsRemU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args

        if regs[rb] == 0:
            res = regs[ra]
        else:
            res = regs[ra] % regs[rb]
        regs[rd] = res


@instr(206, "rem_s_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsRemS64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        wa = regs[ra]
        wb = regs[rb]
        zwa = zeta(8, wa)
        zwb = zeta(8, wb)

        if wb == 0:
            res = wa
        elif zwa == -(2**63) and zwb == -1:
            res = 0
        else:
            res = zeta_inv(8, smod(zwa, zwb))
        regs[rd] = res


@instr(207, "shlo_l_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsShloL64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = cast_64(regs[ra] * 2 ** (regs[rb] % 64))


@instr(208, "shlo_r_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsShloR64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = cast_64(floor(regs[ra] // 2 ** (regs[rb] % 64)))


@instr(209, "shar_r_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsSharR64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = zeta_inv(8, floor(zeta(8, regs[ra]) // 2 ** (regs[rb] % 64)))


@instr(210, "and", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsAnd(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = bw_and(regs[ra], regs[rb])


@instr(211, "xor", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsXor(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = bw_xor(regs[ra], regs[rb])


@instr(212, "or", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsOr(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = bw_or(regs[ra], regs[rb])


@instr(
    213, "mul_upper_s_s", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2])
)
class InsMulUpperSS(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = zeta_inv(8, floor(zeta(8, regs[ra]) * zeta(8, regs[rb]) // 2**64))


@instr(
    214, "mul_upper_u_u", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2])
)
class InsMulUpperUU(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = floor((regs[ra] * regs[rb]) // 2**64)


@instr(
    215, "mul_upper_s_u", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2])
)
class InsMulUpperSU(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        zwa = zeta(8, regs[ra])
        regs[rd] = zeta_inv(8, floor(zwa * regs[rb] // 2**64))


@instr(216, "set_lt_u", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsSetLtU(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = int(regs[ra] < regs[rb])


@instr(217, "set_lt_s", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsSetLtS(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = int(zeta(8, regs[ra]) < zeta(8, regs[rb]))


# NOTE: 2 is also src https://github.com/gavofyork/graypaper/pull/559/changes
@instr(218, "cmov_iz", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1, 2], [2]))
class InsCmovIz(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        if regs[rb] == 0:
            regs[rd] = regs[ra]


# NOTE: 2 is also src https://github.com/gavofyork/graypaper/pull/559/changes
@instr(219, "cmov_nz", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1, 2], [2]))
class InsCmovNz(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        if regs[rb] != 0:
            regs[rd] = regs[ra]


@instr(220, "rot_l_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsRotL64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = rot_l(8, regs[ra], regs[rb])


@instr(221, "rot_l_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsRotL32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = signed_extension_function(4, rot_l(4, regs[ra], regs[rb]))


@instr(222, "rot_r_64", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsRotR64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = rot_r(8, regs[ra], regs[rb])


@instr(223, "rot_r_32", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsRotR32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = signed_extension_function(4, rot_r(4, regs[ra], regs[rb]))


@instr(224, "and_inv", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsAndInv(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = bw_and_inv(regs[ra], regs[rb])


@instr(225, "or_inv", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsOrInv(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = bw_or_inv(regs[ra], regs[rb])


@instr(226, "xnor", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsXnor(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = bw_xnor(regs[ra], regs[rb])


@instr(227, "max", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsMax(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = zeta_inv(
            8,
            max(
                zeta(8, regs[ra]),
                zeta(8, regs[rb]),
            ),
        )


@instr(228, "max_u", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsMaxU(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = max(regs[ra], regs[rb])


@instr(229, "min", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsMin(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = zeta_inv(
            8,
            min(
                zeta(8, regs[ra]),
                zeta(8, regs[rb]),
            ),
        )


@instr(230, "min_u", n_reg=3, decoder=_decode_3reg, source_dest_regs=([0, 1], [2]))
class InsMinU(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, rd = args
        regs[rd] = min(regs[ra], regs[rb])


# $(0.8.0 - A.35)
INSTR_3REG_LIST = [
    InsAdd32,
    InsSub32,
    InsMul32,
    InsDivU32,
    InsDivS32,
    InsRemU32,
    InsRemS32,
    InsShloL32,
    InsShloR32,
    InsSharR32,
    InsAdd64,
    InsSub64,
    InsMul64,
    InsDivU64,
    InsDivS64,
    InsRemU64,
    InsRemS64,
    InsShloL64,
    InsShloR64,
    InsSharR64,
    InsAnd,
    InsXor,
    InsOr,
    InsMulUpperSS,
    InsMulUpperUU,
    InsMulUpperSU,
    InsSetLtU,
    InsSetLtS,
    InsCmovIz,
    InsCmovNz,
    InsRotL32,
    InsRotL64,
    InsRotR32,
    InsRotR64,
    InsAndInv,
    InsOrInv,
    InsXnor,
    InsMax,
    InsMaxU,
    InsMin,
    InsMinU,
]
