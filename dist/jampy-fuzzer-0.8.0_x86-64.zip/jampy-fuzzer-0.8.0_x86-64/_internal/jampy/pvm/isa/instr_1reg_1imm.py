# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from typing import List

from jampy.codec import dnat_l_no_offset, i2b

from ..pvmstate import Memory, PVMExitReasonConstants
from ..utils import cast_8, cast_16, cast_32, signed_extension_function
from .instr import Instr, _decode_1reg_1imm, _decode_1reg_1imm_load_imm_64, instr


@instr(
    20,
    "load_imm_64",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm_load_imm_64,
    source_dest_regs=([], [0]),
)
class InsLoadImm64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        regs[ra] = vx


@instr(
    50,
    "jump_ind",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([0], []),
)
class InsJumpInd(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        res, pc = prog.djump(pc, cast_32(regs[ra] + vx))

        if res != PVMExitReasonConstants.CONTINUE:
            return res, None, pc

        return PVMExitReasonConstants.CONTINUE, None, pc


@instr(
    51,
    "load_imm",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([], [0]),
)
class InsLoadImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        regs[ra] = vx


@instr(
    52,
    "load_u8",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([], [0]),
)
class InsLoadU8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        regs[ra] = mem[vx]


@instr(
    53,
    "load_i8",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([], [0]),
)
class InsLoadI8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        regs[ra] = signed_extension_function(1, mem[vx])


@instr(
    54,
    "load_u16",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([], [0]),
)
class InsLoadU16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        regs[ra] = dnat_l_no_offset(2, mem.get(vx, 2))


@instr(
    55,
    "load_i16",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([], [0]),
)
class InsLoadI16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        regs[ra] = signed_extension_function(2, dnat_l_no_offset(2, mem.get(vx, 2)))


@instr(
    56,
    "load_u32",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([], [0]),
)
class InsLoadU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        regs[ra] = dnat_l_no_offset(4, mem.get(vx, 4))


@instr(
    57,
    "load_i32",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([], [0]),
)
class InsLoadI32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        regs[ra] = signed_extension_function(4, dnat_l_no_offset(4, mem.get(vx, 4)))


@instr(
    58,
    "load_u64",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([], [0]),
)
class InsLoadU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        regs[ra] = dnat_l_no_offset(8, mem.get(vx, 8))


@instr(
    59,
    "store_u8",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([0], []),
)
class InsStoreU8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        mem[vx] = cast_8(regs[ra])


@instr(
    60,
    "store_u16",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([0], []),
)
class InsStoreU16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        mem.memcpy(vx, i2b(2, cast_16(regs[ra])))


@instr(
    61,
    "store_u32",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([0], []),
)
class InsStoreU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        mem.memcpy(vx, i2b(4, cast_32(regs[ra])))


@instr(
    62,
    "store_u64",
    n_reg=1,
    n_imm=1,
    decoder=_decode_1reg_1imm,
    source_dest_regs=([0], []),
)
class InsStoreU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx = args
        mem.memcpy(vx, i2b(8, regs[ra]))


# $(0.8.0 - A.25 / A.27)
INSTR_1REG_1IMM_LIST = [
    InsLoadImm64,
    InsLoadI32,
    InsLoadU64,
    InsLoadU32,
    InsLoadU16,
    InsLoadI16,
    InsLoadU8,
    InsLoadI8,
    InsJumpInd,
    InsLoadImm,
    InsStoreU8,
    InsStoreU16,
    InsStoreU32,
    InsStoreU64,
]
