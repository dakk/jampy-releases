# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


from typing import List

from ..pvmstate import Memory, PVMExitReasonConstants
from ..utils import zeta
from .instr import Instr, _decode_2reg_1off, instr


@instr(
    170,
    "branch_eq",
    n_reg=2,
    n_off=1,
    decoder=_decode_2reg_1off,
    source_dest_regs=([0, 1], []),
)
class InsBranchEq(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[ra] == regs[rb]:
            res, pc = prog.branch_if(pc, vx % mem.size, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    171,
    "branch_ne",
    n_reg=2,
    n_off=1,
    decoder=_decode_2reg_1off,
    source_dest_regs=([0, 1], []),
)
class InsBranchNe(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[ra] != regs[rb]:
            res, pc = prog.branch_if(pc, vx % mem.size, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    172,
    "branch_lt_u",
    n_reg=2,
    n_off=1,
    decoder=_decode_2reg_1off,
    source_dest_regs=([0, 1], []),
)
class InsBranchLtU(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[ra] < regs[rb]:
            res, pc = prog.branch_if(pc, vx % mem.size, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    173,
    "branch_lt_s",
    n_reg=2,
    n_off=1,
    decoder=_decode_2reg_1off,
    source_dest_regs=([0, 1], []),
)
class InsBranchLtS(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if zeta(8, regs[ra]) < zeta(8, regs[rb]):
            res, pc = prog.branch_if(pc, vx % mem.size, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    174,
    "branch_ge_u",
    n_reg=2,
    n_off=1,
    decoder=_decode_2reg_1off,
    source_dest_regs=([0, 1], []),
)
class InsBranchGeU(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[ra] >= regs[rb]:
            res, pc = prog.branch_if(pc, vx % mem.size, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    175,
    "branch_ge_s",
    n_reg=2,
    n_off=1,
    decoder=_decode_2reg_1off,
    source_dest_regs=([0, 1], []),
)
class InsBranchGeS(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if zeta(8, regs[ra]) >= zeta(8, regs[rb]):
            res, pc = prog.branch_if(pc, vx % mem.size, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


# $(0.8.0 - A.33)
INSTR_2REG_1OFF_LIST = [
    InsBranchEq,
    InsBranchNe,
    InsBranchLtU,
    InsBranchLtS,
    InsBranchGeU,
    InsBranchGeS,
]
