# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


from .instr import Instr  # noqa: F401
from .instr_1imm import INSTR_1IMM_LIST
from .instr_1off import INSTR_1OFF_LIST
from .instr_1reg_1imm import INSTR_1REG_1IMM_LIST
from .instr_1reg_1imm_1off import INSTR_1REG_1IMM_1OFF_LIST
from .instr_1reg_2imm import INSTR_1REG_2IMM_LIST
from .instr_2imm import INSTR_2IMM_LIST
from .instr_2reg import INSTR_2REG_LIST
from .instr_2reg_1imm import INSTR_2REG_1IMM_LIST
from .instr_2reg_1off import INSTR_2REG_1OFF_LIST
from .instr_2reg_2imm import INSTR_2REG_2IMM_LIST
from .instr_3reg import INSTR_3REG_LIST
from .instr_noarg import INSTR_NOARG_LIST

INSTRUCTIONS = [
    i()  # type: ignore
    for i in (
        INSTR_NOARG_LIST
        + INSTR_1IMM_LIST
        + INSTR_1OFF_LIST
        + INSTR_1REG_1IMM_LIST
        + INSTR_1REG_1IMM_1OFF_LIST
        + INSTR_2IMM_LIST
        + INSTR_3REG_LIST
        + INSTR_2REG_1IMM_LIST
        + INSTR_1REG_2IMM_LIST
        + INSTR_2REG_LIST
        + INSTR_2REG_1OFF_LIST
        + INSTR_2REG_2IMM_LIST
    )
]

OPCODES = []
INSTRUCTIONS_MAP = {}
IL_LEN = 240
INSTRUCTIONS_LIST = [INSTRUCTIONS[0]] * IL_LEN
for i in INSTRUCTIONS:
    INSTRUCTIONS_MAP[i.opcode] = i
    OPCODES.append(i.opcode)
    INSTRUCTIONS_LIST[i.opcode] = i
