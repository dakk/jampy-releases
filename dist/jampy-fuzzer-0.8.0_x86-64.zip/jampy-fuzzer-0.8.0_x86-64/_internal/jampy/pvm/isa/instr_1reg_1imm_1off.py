# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from typing import List

from ..pvmstate import Memory, PVMExitReasonConstants
from ..utils import zeta
from .instr import Instr, _decode_1reg_1imm_1off, instr


@instr(
    80,
    "load_imm_jump",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsLoadImmJump(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        res, pc = prog.sjump(pc, vy)
        regs[ra] = vx
        return res, None, pc


@instr(
    81,
    "branch_eq_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchEqImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] == vx:
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    82,
    "branch_ne_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchNeImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] != vx:
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    83,
    "branch_lt_u_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchLtUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] < vx:
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    84,
    "branch_le_u_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchLeUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] <= vx:
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    85,
    "branch_ge_u_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchGeUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] >= vx:
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    86,
    "branch_gt_u_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchGtUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] > vx:
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    87,
    "branch_lt_s_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchLtSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if zeta(8, regs[ra]) < zeta(8, vx):
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    88,
    "branch_le_s_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchLeSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if zeta(8, regs[ra]) <= zeta(8, vx):
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    89,
    "branch_ge_s_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchGeSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if zeta(8, regs[ra]) >= zeta(8, vx):
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(
    90,
    "branch_gt_s_imm",
    n_reg=1,
    n_imm=1,
    n_off=1,
    decoder=_decode_1reg_1imm_1off,
    source_dest_regs=([0], []),
)
class InsBranchGtSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if zeta(8, regs[ra]) > zeta(8, vx):
            res, pc = prog.branch_if(pc, vy, True)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


# $(0.8.0 - A.30)
INSTR_1REG_1IMM_1OFF_LIST = [
    InsLoadImmJump,
    InsBranchEqImm,
    InsBranchNeImm,
    InsBranchLtUImm,
    InsBranchLeUImm,
    InsBranchGeUImm,
    InsBranchGtUImm,
    InsBranchLtSImm,
    InsBranchLeSImm,
    InsBranchGtSImm,
    InsBranchGeSImm,
]
