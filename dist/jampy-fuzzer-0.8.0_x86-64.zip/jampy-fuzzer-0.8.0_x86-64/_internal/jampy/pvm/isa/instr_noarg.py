# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from typing import List

from ..pvmstate import Memory, PVMExitReasonConstants
from .instr import Instr, _decode_none, instr

INS_TRAP_OPCODE = 0
INS_UNKLIKELY_OPCODE = 2


@instr(0, "trap", decoder=_decode_none)
class InsTrap(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        return PVMExitReasonConstants.PANIC, None, pc


@instr(1, "fallthrough", decoder=_decode_none)
class InsFallthrough(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        res, pc = prog.sjump(pc, pc + 1 + prog.skip(pc))
        return res, None, pc


@instr(2, "unlikely", decoder=_decode_none)
class InsUnlikely(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        # NOTE: this is not terminating, no return needed
        pass


# $(0.8.0 - A.23)
INSTR_NOARG_LIST = [InsTrap, InsFallthrough, InsUnlikely]
