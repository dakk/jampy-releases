# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from typing import List

from jampy.codec import i2b

from ..pvmstate import Memory
from ..utils import cast_8, cast_16, cast_32
from .instr import Instr, _decode_1reg_2imm, instr


@instr(
    70,
    "store_imm_ind_u8",
    n_reg=1,
    n_imm=2,
    decoder=_decode_1reg_2imm,
    source_dest_regs=([0], []),
)
class InsStoreImmIndU8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        mem[regs[ra] + vx] = cast_8(vy)


@instr(
    71,
    "store_imm_ind_u16",
    n_reg=1,
    n_imm=2,
    decoder=_decode_1reg_2imm,
    source_dest_regs=([0], []),
)
class InsStoreImmIndU16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        mem.memcpy(regs[ra] + vx, i2b(2, cast_16(vy)))


@instr(
    72,
    "store_imm_ind_u32",
    n_reg=1,
    n_imm=2,
    decoder=_decode_1reg_2imm,
    source_dest_regs=([0], []),
)
class InsStoreImmIndU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        mem.memcpy(regs[ra] + vx, i2b(4, cast_32(vy)))


@instr(
    73,
    "store_imm_ind_u64",
    n_reg=1,
    n_imm=2,
    decoder=_decode_1reg_2imm,
    source_dest_regs=([0], []),
)
class InsStoreImmIndU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        mem.memcpy(regs[ra] + vx, i2b(8, vy))


# $(0.8.0 - A.29)
INSTR_1REG_2IMM_LIST = [
    InsStoreImmIndU8,
    InsStoreImmIndU16,
    InsStoreImmIndU32,
    InsStoreImmIndU64,
]
