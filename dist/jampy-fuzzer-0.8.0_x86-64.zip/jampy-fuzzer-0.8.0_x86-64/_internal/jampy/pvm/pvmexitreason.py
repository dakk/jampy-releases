# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from enum import IntEnum, auto
from typing import Optional, Tuple


# Values from (0.8.0 - B)
class PVMExitReasonConstants(IntEnum):
    HALT = 0
    " The invocation completed and halted normally (quad) "

    PANIC = 1
    " The invocation completed with a panic (flash) "

    FAULT = 2
    " The invocation completed with a page fault (F) "

    HOST = 3
    " The invocation completed with a host-call fault (h) "

    OUT_OF_GAS = 4
    "Exhaustion of gas (inf)"

    CONTINUE = auto()
    "Continue execution (play)"

    def __repr__(self):
        return (
            self.name.lower()
            .replace("_", "-")
            .replace("fault", "page-fault")
            .replace("host", "ecalli")
        )


PVMExitReason = Tuple[PVMExitReasonConstants, Optional[int]]
" Status x (Fault_page | Hostcall_iden)"
