# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

# from dataclasses import dataclass
from functools import cached_property
from typing import List, Tuple

from .decode import DecodeError  # , Decoder
from .encode import Encoder


class BitSequence:
    __slots__ = ("_data", "_n")

    def __init__(self, n: int, data: bytes = b""):
        self._n = n
        self._data = data[: (n + 7) >> 3] if data else bytes((n + 7) >> 3)

    def __getitem__(self, idx: int) -> bool:
        return bool(self._data[idx >> 3] & (1 << (idx & 7)))

    def __len__(self) -> int:
        return self._n

    def __iter__(self):
        return (self[i] for i in range(self._n))

    def to_bytes(self) -> bytes:
        return self._data


class Bitfield:
    def __init__(self, n: int, bits: "BitSequence | List[bool]"):
        if isinstance(bits, list):
            self._bits = BitSequence(n, Encoder.encode_bit_sequence(bits))
        else:
            self._bits = bits

    @property
    def n(self) -> int:
        return len(self._bits)

    def __len__(self) -> int:
        return len(self._bits)

    def __getitem__(self, i: int) -> bool:
        return self._bits[i]

    @cached_property
    def filled_with_ones(self) -> BitSequence:
        data = bytearray(self._bits.to_bytes())
        if self.n & 7:
            data[-1] |= (0xFF << (self.n & 7)) & 0xFF
        return BitSequence(self.n + 64, bytes(data) + bytes([255] * 8))

    @property
    def hex(self) -> str:
        from jampy.utils import to_hex

        return to_hex(self._bits.to_bytes())

    @property
    def val(self) -> bytes:
        return self._bits.to_bytes()

    def as_list(self) -> List[bool]:
        return list(self._bits)

    @staticmethod
    def from_list(l: List[bool]) -> "Bitfield":
        n = len(l)
        return Bitfield(n, BitSequence(n, Encoder.encode_bit_sequence(l)))

    @staticmethod
    def from_hex(n: int, bf: str) -> "Bitfield":
        from jampy.utils import from_hex

        data = from_hex(bf)
        byte_size = (n + 7) >> 3
        if len(data) > byte_size:
            raise DecodeError("Bitfield from_hex decode error (left bytes)")
        return Bitfield(n, BitSequence(n, data))

    @staticmethod
    def from_bytes(n: int, bf: bytes) -> Tuple["Bitfield", bytes]:
        byte_size = (n + 7) >> 3
        return Bitfield(n, BitSequence(n, bf)), bf[byte_size:]

    def to_bytes(self) -> bytes:
        return self._bits.to_bytes()

    def to_json(self) -> str:
        return self.hex
