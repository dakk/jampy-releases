# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import json
from typing import Dict, Tuple


class JSONDecodeError(Exception):
    def __init__(self, *args):
        super().__init__(*args)


class Serializable:
    @staticmethod
    def from_bytes(b: bytes) -> Tuple["Serializable", bytes]:
        raise NotImplementedError("Abstract")

    def to_bytes(self) -> bytes:
        raise NotImplementedError("Abstract")


class JSONSerializable:
    @staticmethod
    def from_json(b: Dict) -> "JSONSerializable":
        raise NotImplementedError("Abstract: JSONSerializable.from_json")

    @classmethod
    def from_json_file(cls, jfile: str):
        f = open(jfile, "r")
        jdata = json.loads(f.read())
        f.close()
        return cls.from_json(jdata)

    def to_json(self) -> Dict:
        raise NotImplementedError("Abstract: JSONSerializable.to_json")
