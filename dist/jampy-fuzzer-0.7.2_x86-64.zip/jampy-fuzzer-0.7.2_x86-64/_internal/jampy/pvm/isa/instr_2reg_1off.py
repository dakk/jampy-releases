# Copyright (C) 2024-2025 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from typing import List

from ..pvmstate import Memory, PVMExitReasonConstants
from ..utils import zeta
from .instr import Instr, _decode_2reg_1off, instr


@instr(170, "branch_eq", n_reg=2, n_off=1, decoder=_decode_2reg_1off)
class InsBranchEq(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[ra] == regs[rb]:
            (res, pc) = prog.branch(pc, vx % mem.size)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(171, "branch_ne", n_reg=2, n_off=1, decoder=_decode_2reg_1off)
class InsBranchNe(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[ra] != regs[rb]:
            (res, pc) = prog.branch(pc, vx % mem.size)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(172, "branch_lt_u", n_reg=2, n_off=1, decoder=_decode_2reg_1off)
class InsBranchLtU(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[ra] < regs[rb]:
            (res, pc) = prog.branch(pc, vx % mem.size)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(173, "branch_lt_s", n_reg=2, n_off=1, decoder=_decode_2reg_1off)
class InsBranchLtS(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if zeta(8, regs[ra]) < zeta(8, regs[rb]):
            (res, pc) = prog.branch(pc, vx % mem.size)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(174, "branch_ge_u", n_reg=2, n_off=1, decoder=_decode_2reg_1off)
class InsBranchGeU(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[ra] >= regs[rb]:
            (res, pc) = prog.branch(pc, vx % mem.size)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(175, "branch_ge_s", n_reg=2, n_off=1, decoder=_decode_2reg_1off)
class InsBranchGeS(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if zeta(8, regs[ra]) >= zeta(8, regs[rb]):
            (res, pc) = prog.branch(pc, vx % mem.size)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


# $(0.7.2 - A.30)
INSTR_2REG_1OFF_LIST = [
    InsBranchEq,
    InsBranchNe,
    InsBranchLtU,
    InsBranchLtS,
    InsBranchGeU,
    InsBranchGeS,
]
