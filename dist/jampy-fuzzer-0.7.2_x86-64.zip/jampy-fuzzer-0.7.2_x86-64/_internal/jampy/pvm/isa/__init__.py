# Copyright (C) 2024-2025 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from .instr import Instr  # noqa: F401
from .instr_1imm import INSTR_1IMM_LIST
from .instr_1off import INSTR_1OFF_LIST
from .instr_1reg_1imm import INSTR_1REG_1IMM_LIST
from .instr_1reg_1imm_1off import INSTR_1REG_1IMM_1OFF_LIST
from .instr_1reg_2imm import INSTR_1REG_2IMM_LIST
from .instr_2imm import INSTR_2IMM_LIST
from .instr_2reg import INSTR_2REG_LIST
from .instr_2reg_1imm import INSTR_2REG_1IMM_LIST
from .instr_2reg_1off import INSTR_2REG_1OFF_LIST
from .instr_2reg_2imm import INSTR_2REG_2IMM_LIST
from .instr_3reg import INSTR_3REG_LIST
from .instr_noarg import INSTR_NOARG_LIST

INSTRUCTIONS = [
    i()  # type: ignore
    for i in (
        INSTR_NOARG_LIST
        + INSTR_1IMM_LIST
        + INSTR_1OFF_LIST
        + INSTR_1REG_1IMM_LIST
        + INSTR_1REG_1IMM_1OFF_LIST
        + INSTR_2IMM_LIST
        + INSTR_3REG_LIST
        + INSTR_2REG_1IMM_LIST
        + INSTR_1REG_2IMM_LIST
        + INSTR_2REG_LIST
        + INSTR_2REG_1OFF_LIST
        + INSTR_2REG_2IMM_LIST
    )
]

OPCODES = []
INSTRUCTIONS_MAP = {}
IL_LEN = 240
INSTRUCTIONS_LIST = [INSTRUCTIONS[0]] * IL_LEN
for i in INSTRUCTIONS:
    INSTRUCTIONS_MAP[i.opcode] = i
    OPCODES.append(i.opcode)
    INSTRUCTIONS_LIST[i.opcode] = i
