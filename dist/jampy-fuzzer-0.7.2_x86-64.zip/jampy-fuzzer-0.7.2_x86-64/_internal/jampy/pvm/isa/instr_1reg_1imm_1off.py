# Copyright (C) 2024-2026 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List

from ..pvmstate import Memory, PVMExitReasonConstants
from ..utils import zeta
from .instr import Instr, _decode_1reg_1imm_1off, instr


@instr(80, "load_imm_jump", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsLoadImmJump(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        res, pc = prog.branch(pc, vy)
        regs[ra] = vx
        return res, None, pc


@instr(81, "branch_eq_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchEqImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] == vx:
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(82, "branch_ne_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchNeImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] != vx:
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(83, "branch_lt_u_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchLtUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] < vx:
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(84, "branch_le_u_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchLeUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] <= vx:
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(85, "branch_ge_u_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchGeUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] >= vx:
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(86, "branch_gt_u_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchGtUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if regs[ra] > vx:
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(87, "branch_lt_s_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchLtSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if zeta(8, regs[ra]) < zeta(8, vx):
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(88, "branch_le_s_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchLeSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if zeta(8, regs[ra]) <= zeta(8, vx):
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(89, "branch_ge_s_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchGeSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if zeta(8, regs[ra]) >= zeta(8, vx):
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


@instr(90, "branch_gt_s_imm", n_reg=1, n_imm=1, n_off=1, decoder=_decode_1reg_1imm_1off)
class InsBranchGtSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        if zeta(8, regs[ra]) > zeta(8, vx):
            res, pc = prog.branch(pc, vy)
        else:
            res = PVMExitReasonConstants.CONTINUE
        return res, None, pc


# $(0.7.2 - A.27)
INSTR_1REG_1IMM_1OFF_LIST = [
    InsLoadImmJump,
    InsBranchEqImm,
    InsBranchNeImm,
    InsBranchLtUImm,
    InsBranchLeUImm,
    InsBranchGeUImm,
    InsBranchGtUImm,
    InsBranchLtSImm,
    InsBranchLeSImm,
    InsBranchGtSImm,
    InsBranchGeSImm,
]
