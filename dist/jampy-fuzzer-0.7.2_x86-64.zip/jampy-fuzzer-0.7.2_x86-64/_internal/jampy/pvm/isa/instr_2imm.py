# Copyright (C) 2024-2026 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List

from jampy.codec import i2b

from ..pvmstate import Memory
from ..utils import cast_8, cast_16, cast_32
from .instr import Instr, _decode_2imm, instr


@instr(30, "store_imm_u8", n_imm=2, decoder=_decode_2imm)
class InsStoreImmU8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        vx, vy = args
        mem[vx] = cast_8(vy)


@instr(31, "store_imm_u16", n_imm=2, decoder=_decode_2imm)
class InsStoreImmU16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        vx, vy = args
        mem.memcpy(vx, i2b(2, cast_16(vy)))


@instr(32, "store_imm_u32", n_imm=2, decoder=_decode_2imm)
class InsStoreImmU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        vx, vy = args
        mem.memcpy(vx, i2b(4, cast_32(vy)))


@instr(33, "store_imm_u64", n_imm=2, decoder=_decode_2imm)
class InsStoreImmU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        vx, vy = args
        mem.memcpy(vx, i2b(8, vy))


INSTR_2IMM_LIST = [InsStoreImmU8, InsStoreImmU16, InsStoreImmU32, InsStoreImmU64]
