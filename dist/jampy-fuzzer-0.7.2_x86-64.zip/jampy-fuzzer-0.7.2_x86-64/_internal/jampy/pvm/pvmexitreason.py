# Copyright (C) 2024-2025 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from enum import IntEnum, auto
from typing import Optional, Tuple


# Values from (0.7.2 - B)
class PVMExitReasonConstants(IntEnum):
    HALT = 0
    " The invocation completed and halted normally (quad) "

    PANIC = 1
    " The invocation completed with a panic (flash) "

    FAULT = 2
    " The invocation completed with a page fault (F) "

    HOST = 3
    " The invocation completed with a host-call fault (h) "

    OUT_OF_GAS = 4
    "Exhaustion of gas (inf)"

    CONTINUE = auto()
    "Continue execution (play)"


PVMExitReason = Tuple[PVMExitReasonConstants, Optional[int]]
" Status x (Fault_page | Hostcall_iden)"
