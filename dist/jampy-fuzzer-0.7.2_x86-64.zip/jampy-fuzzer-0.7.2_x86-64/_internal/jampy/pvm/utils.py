# Copyright (C) 2024-2025 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from math import ceil, floor

# from .utilsc import signed_extension_function


# Precompute masks and signbits for allowed n
_SEF_MASK = {
    0: 0,
    1: 0xFF,
    2: 0xFFFF,
    3: 0xFFFFFF,
    4: 0xFFFFFFFF,
    8: 0xFFFFFFFFFFFFFFFF,
}
_SEF_SIGN = {
    0: 0,
    1: 0x80,
    2: 0x8000,
    3: 0x800000,
    4: 0x80000000,
    8: 0x8000000000000000,
}


def signed_extension_function(n: int, x: int) -> int:
    "X $(0.7.2 - A.17)"
    try:
        mask = _SEF_MASK[n]
        signbit = _SEF_SIGN[n]
    except KeyError:
        raise ValueError(f"invalid n={n} in signed_extension_function()")

    if n == 0:
        return 0

    x &= mask
    if x & signbit:
        return x | (~mask & 0xFFFFFFFFFFFFFFFF)
    return x


# def signed_extension_function(n: int, x: int) -> int:
#     "X $(0.7.2 - A.17)"
#     if n not in (0, 1, 2, 3, 4, 8):
#         raise ValueError(f"invalid n={n} in signed_extension_function()")

#     if n == 0:
#         return 0

#     bits = 8 * n
#     signbit = 1 << (bits - 1)
#     mask = (1 << bits) - 1

#     x &= mask
#     if x & signbit:
#         return x | (~mask & ((1 << 64) - 1))
#     return x


# def signed_extension_function(n: int, x: int) -> int:
#     "X $(0.7.2 - A.17)"
#     if n not in [0, 1, 2, 3, 4, 8]:
#         raise Exception("invalid value on signed_extension_funcion()", n)

#     return x + floor(x / (2 ** (8 * n - 1))) * (2**64 - 2 ** (8 * n))

ZETA_MASK = [
    0,
    0xFF,
    0xFFFF,
    0xFFFFFF,
    0xFFFFFFFF,
    0xFFFFFFFFFF,
    0xFFFFFFFFFFFF,
    0xFFFFFFFFFFFFFF,
    0xFFFFFFFFFFFFFFFF,
]
ZETA_SIGN = [
    0,
    0x80,
    0x8000,
    0x800000,
    0x80000000,
    0x8000000000,
    0x800000000000,
    0x80000000000000,
    0x8000000000000000,
]


def zeta(n: int, a: int) -> int:
    return ((a & ZETA_MASK[n]) ^ ZETA_SIGN[n]) - ZETA_SIGN[n]


# def zeta(n: int, a: int) -> int:
#     "Z $(0.7.2 - A.10)"
#     bits = 8 * n
#     signbit = 1 << (bits - 1)
#     mask = (1 << bits) - 1
#     a &= mask
#     return (a ^ signbit) - signbit


# def zeta(n: int, a: int) -> int:
#     "Z $(0.7.2 - A.10)"
#     if a < 2 ** (8 * n - 1):
#         return a
#     else:
#         return a - 2 ** (8 * n)


# def zeta_inv(n: int, a: int) -> int:
#     "Z ** (-1) $(0.7.2 - A.11)"
#     return (2 ** (8 * n) + a) % (2 ** (8 * n))


def zeta_inv(n: int, a: int) -> int:
    "Z ** (-1) $(0.7.2 - A.11)"
    mask = (1 << (8 * n)) - 1
    return a & mask


# TODO: Not used anymore
# def beta(s: int, n: int) -> list[bool]:
#     "B $(0.7.2 - A.12)"
#     bits = s * 8
#     n &= (1 << bits) - 1
#     return [(n >> i) & 1 == 1 for i in reversed(range(bits))]


# TODO: Not used anymore
# def beta_inv(s: int, b: list[bool]) -> int:
#     "B inv $(0.7.2 - A.13)"
#     out = 0
#     for bit in b:
#         out = (out << 1) | bit
#     return out

# TODO: Not used anymore
# def beta_rev(s: int, n: int) -> List[bool]:
#     "B rev $(0.7.2 - A.14)"
#     return beta(s, n)[::-1]


# TODO: Not used anymore
# def beta_rev_inv(s: int, b: List[bool]) -> int:
#     "B rev inv $(0.7.2 - A.15)"
#     return beta_inv(s, b[::-1])


def smod(a: int, b: int) -> int:
    "Signed mod (smod) $(0.7.2 - A.33)"
    if b == 0:
        return a

    r = abs(a) % abs(b)
    if a < 0:
        return -r
    else:
        return r


def rtz(x: int) -> int:
    "Division operations always round their result towards zero $(0.7.2 - A.34)"
    # TODO: this may be useless since we have our python numerical fix
    if x < 0:
        return ceil(x)
    else:
        return floor(x)


def cast_8(n: int) -> int:
    return n & 0xFF


def cast_16(n: int) -> int:
    return n & 0xFFFF


def cast_32(n: int) -> int:
    return n & 0xFFFFFFFF


def cast_64(n: int) -> int:
    return n & 0xFFFFFFFFFFFFFFFF


def rot_r(s: int, n: int, p: int) -> int:
    "Rotate right (bit shift)"
    bits = s * 8
    p %= bits
    n &= (1 << bits) - 1
    return ((n >> p) | (n << (bits - p))) & ((1 << bits) - 1)


def rot_l(s: int, n: int, p: int) -> int:
    "Rotate left (bit shift)"
    bits = s * 8
    p %= bits
    n &= (1 << bits) - 1
    return ((n << p) | (n >> (bits - p))) & ((1 << bits) - 1)


def bw_xnor(a: int, b: int) -> int:
    return ~(a ^ b) & 0xFFFFFFFFFFFFFFFF


def bw_xor(a: int, b: int) -> int:
    return (a ^ b) & 0xFFFFFFFFFFFFFFFF


def bw_or(a: int, b: int) -> int:
    return (a | b) & 0xFFFFFFFFFFFFFFFF


def bw_or_inv(a: int, b: int) -> int:
    return (a | (~b)) & 0xFFFFFFFFFFFFFFFF


def bw_and(a: int, b: int) -> int:
    return (a & b) & 0xFFFFFFFFFFFFFFFF


def bw_and_inv(a: int, b: int) -> int:
    return (a & (~b)) & 0xFFFFFFFFFFFFFFFF
