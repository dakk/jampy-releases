# Copyright (C) 2024-2026 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math
from decimal import Decimal
from functools import reduce
from operator import add
from typing import Any, Dict, List, Sequence, Set, Tuple


class EncodeError(Exception):
    def __init__(self, *args):
        super().__init__(*args)


def i2b(length: int, x: int):
    return int.to_bytes(x, length=length, byteorder="little", signed=False)


class Encoder:
    """Encoder implementing E(x) (0.4.5 - Appendix C)"""

    @staticmethod
    def encode_void() -> bytes:
        "Encode void $(0.7.2 - C.1)"
        return bytes()

    @staticmethod
    def encode_octet(b: bytes) -> bytes:
        "Encode octet $(0.7.2 - C.2)"
        return b

    @staticmethod
    def encode_tuple(t: Tuple) -> bytes:
        "Encode tuple $(0.7.2 - C.3)"
        return reduce(add, map(lambda v: Encoder.encode(v), t), bytes())

    @staticmethod
    def encode_args(*args) -> bytes:
        "Encode args $(0.7.2 - C.4)"
        return Encoder.encode_tuple(args)

    @staticmethod
    def encode_nat_l(l: int, x: int) -> bytes:
        "Encoding natural number, little-endian $(0.7.2 - C.12 / C.13 / C.14 / C.15)"
        return i2b(l, x)

    @staticmethod
    def encode_nat(x: int) -> bytes:
        "General nat encoding $(0.7.2 - C.5)"
        if x == 0:
            return bytes([0])

        # Find an l in N8 | 2**(7*l) <= x < 2**(7*(l+1))
        def find_l(l=0):
            if l >= 8:
                return None
            if x >= (2 ** (7 * l)) and x < 2 ** (7 * (l + 1)):
                return l
            else:
                return find_l(l + 1)

        l = find_l()

        if l is None and x < 2**64:
            return i2b(1, 2**8 - 1) + Encoder.encode_nat_l(8, x)
        elif l is None:
            raise EncodeError(f"l is None, x is {x}")

        return i2b(
            1, 2**8 - 2 ** (8 - l) + math.floor(Decimal(x) / Decimal(2 ** (8 * l)))
        ) + Encoder.encode_nat_l(l, x % (2 ** (8 * l)))

    @staticmethod
    def encode_sequence(s: Sequence) -> bytes:
        "Encode sequence $(0.7.2 - C.6)"
        return Encoder.encode_args(*s)

    @staticmethod
    def encode_set(s: Set) -> bytes:
        "Encode set $(0.7.2 - C.11)"
        return Encoder.encode_tuple(tuple(s))

    @staticmethod
    def encode_variable_size(v: Any) -> bytes:
        "Encode variable size (of bytes)  $(0.7.2 - C.7)"
        v_enc = Encoder.encode(v)
        return Encoder.encode_nat(len(v_enc)) + v_enc

    @staticmethod
    def encode_optional(v: Any) -> bytes:
        "Encode optional value $(0.7.2 - C.8)"
        v_enc = Encoder.encode(v)
        if v is None or len(v) == 0:
            return bytes([0])
        return Encoder.encode_tuple((i2b(1, 1), v_enc))

    @staticmethod
    def encode_bit_sequence(b: List[bool]) -> bytes:
        "Encode bit sequence $(0.7.2 - C.9)"
        if not b:
            return b""
        n = len(b)
        byte_size = (n + 7) >> 3
        result = bytearray(byte_size)
        for byte_idx in range(byte_size):
            bv = 0
            for i, bit in enumerate(b[byte_idx * 8 : (byte_idx + 1) * 8]):
                if bit:
                    bv |= 1 << i
            result[byte_idx] = bv
        return bytes(result)

    @staticmethod
    def encode_dict(d: Dict[Any, Any]) -> bytes:
        "Dictionary encoding $(0.7.2 - C.10)"
        raise Exception("Don't use")

        d_enc = {}

        for k, v in d.items():
            d_enc[Encoder.encode(k)] = Encoder.encode(v)

        res = bytes()

        k_enc = list(d_enc.keys())
        k_enc.sort()
        for k in k_enc:
            res += k + d_enc[k]

        return Encoder.encode_variable_size(res)

    @staticmethod
    def encode_list(l: List, sized: bool) -> bytes:
        b = b""

        if sized:
            b += Encoder.encode_nat(len(l))

        for i in l:
            b += i.to_bytes()

        return b

    @staticmethod
    def encode(v: Any):
        if type(v) is int:
            return Encoder.encode_nat(v)
        elif type(v) is bytes:
            return Encoder.encode_octet(v)
        elif type(v) is dict:
            return Encoder.encode_dict(v)
        elif type(v) is tuple:
            return Encoder.encode_tuple(v)
        elif type(v) is set:
            return Encoder.encode_set(v)
        elif type(v) is list:
            if all(map(lambda v: type(v) is bool, v)):
                return Encoder.encode_bit_sequence(v)
            return Encoder.encode_sequence(v)
        else:
            return Encoder.encode_void()


def encode(v: Any) -> bytes:
    return Encoder.encode(v)
