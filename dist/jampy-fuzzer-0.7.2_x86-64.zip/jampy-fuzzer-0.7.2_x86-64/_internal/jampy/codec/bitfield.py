# Copyright (C) 2024-2026 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# from dataclasses import dataclass
from functools import cached_property
from typing import List, Tuple

from .decode import DecodeError  # , Decoder
from .encode import Encoder


class BitSequence:
    __slots__ = ("_data", "_n")

    def __init__(self, n: int, data: bytes = b""):
        self._n = n
        self._data = data[: (n + 7) >> 3] if data else bytes((n + 7) >> 3)

    def __getitem__(self, idx: int) -> bool:
        return bool(self._data[idx >> 3] & (1 << (idx & 7)))

    def __len__(self) -> int:
        return self._n

    def __iter__(self):
        return (self[i] for i in range(self._n))

    def to_bytes(self) -> bytes:
        return self._data


class Bitfield:
    def __init__(self, n: int, bits: "BitSequence | List[bool]"):
        if isinstance(bits, list):
            self._bits = BitSequence(n, Encoder.encode_bit_sequence(bits))
        else:
            self._bits = bits

    @property
    def n(self) -> int:
        return len(self._bits)

    def __getitem__(self, i: int) -> bool:
        return self._bits[i]

    @cached_property
    def filled_with_ones(self) -> BitSequence:
        return BitSequence(self.n + 64, self._bits.to_bytes() + bytes([255] * 8))

    @property
    def hex(self) -> str:
        from jampy.utils import to_hex

        return to_hex(self._bits.to_bytes())

    @property
    def val(self) -> bytes:
        return self._bits.to_bytes()

    def as_list(self) -> List[bool]:
        return list(self._bits)

    @staticmethod
    def from_list(l: List[bool]) -> "Bitfield":
        n = len(l)
        return Bitfield(n, BitSequence(n, Encoder.encode_bit_sequence(l)))

    @staticmethod
    def from_hex(n: int, bf: str) -> "Bitfield":
        from jampy.utils import from_hex
        data = from_hex(bf)
        byte_size = (n + 7) >> 3
        if len(data) > byte_size:
            raise DecodeError(f"Bitfield from_hex decode error (left bytes ({len(data) - byte_size}))")
        return Bitfield(n, BitSequence(n, data))

    @staticmethod
    def from_bytes(n: int, bf: bytes) -> Tuple["Bitfield", bytes]:
        byte_size = (n + 7) >> 3
        return Bitfield(n, BitSequence(n, bf)), bf[byte_size:]

    def to_bytes(self) -> bytes:
        return self._bits.to_bytes()

    def to_json(self) -> str:
        return self.hex


# from dataclasses import dataclass
# from .decode import Decoder
# @dataclass
# class Bitfield:
#     n: int
#     bf: List[bool]

#     def __getitem__(self, i):
#         return self.bf[i]

#     @cached_property
#     def filled_with_ones(self):
#         return self.bf + [True] * 64

#     @property
#     def hex(self) -> str:
#         from jampy.utils import to_hex

#         return to_hex(Encoder.encode_bit_sequence(self.bf))

#     @property
#     def val(self) -> bytes:
#         return Encoder.encode_bit_sequence(self.bf)

#     def as_list(self) -> List[bool]:
#         return self.bf

#     @staticmethod
#     def from_list(l: List[bool]) -> "Bitfield":
#         return Bitfield(len(l), l)

#     @staticmethod
#     def from_hex(n: int, bf: str) -> "Bitfield":
#         from jampy.utils import from_hex

#         bs, rest = Decoder.decode_bit_sequence(n, from_hex(bf))
#         if len(rest) > 0:
#             raise DecodeError(f"Bitfield from_hex decode error (left bytes ({len(rest)}))")

#         return Bitfield(n, bs)

#     @staticmethod
#     def from_bytes(n: int, bf: bytes) -> Tuple["Bitfield", bytes]:
#         bs, rest = Decoder.decode_bit_sequence(n, bf)
#         return Bitfield(n, bs), rest

#     def to_bytes(self):
#         return self.val

#     def to_json(self):
#         return self.hex