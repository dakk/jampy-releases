# Copyright (C) 2024-2026 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
from typing import Dict, Tuple


class JSONDecodeError(Exception):
    def __init__(self, *args):
        super().__init__(*args)


class Serializable:
    @staticmethod
    def from_bytes(b: bytes) -> Tuple["Serializable", bytes]:
        raise NotImplementedError("Abstract")

    def to_bytes(self) -> bytes:
        raise NotImplementedError("Abstract")


class JSONSerializable:
    @staticmethod
    def from_json(b: Dict) -> "JSONSerializable":
        raise NotImplementedError("Abstract: JSONSerializable.from_json")

    @classmethod
    def from_json_file(cls, jfile: str):
        f = open(jfile, "r")
        jdata = json.loads(f.read())
        f.close()
        return cls.from_json(jdata)

    def to_json(self) -> Dict:
        raise NotImplementedError("Abstract: JSONSerializable.to_json")
