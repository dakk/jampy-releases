# Copyright (C) 2024-2026 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List

from ..pvmstate import Memory
from ..utils import cast_8, cast_16, cast_32, zeta, zeta_inv
from .instr import Instr, _decode_2reg, instr

INS_MOVE_REG_OPCODE = 100


@instr(100, "move_reg", n_reg=2, decoder=_decode_2reg, source_dest_regs=([1], [0]))
class InsMoveReg(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = regs[ra]


@instr(
    101, "count_set_bits_64", n_reg=2, decoder=_decode_2reg, source_dest_regs=([1], [0])
)
class InsCountSetBits64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = regs[ra] & ((1 << 64) - 1)  # ensure 64-bit
        regs[rd] = regs[ra].bit_count()


@instr(
    102, "count_set_bits_32", n_reg=2, decoder=_decode_2reg, source_dest_regs=([1], [0])
)
class InsCountSetBits32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = cast_32(regs[ra])
        regs[rd] = v.bit_count()


@instr(
    103,
    "leading_zero_bits_64",
    n_reg=2,
    decoder=_decode_2reg,
    source_dest_regs=([1], [0]),
)
class InsLeadingZeroBits64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = regs[ra] & ((1 << 64) - 1)
        regs[rd] = 64 - v.bit_length() if v != 0 else 64


@instr(
    104,
    "leading_zero_bits_32",
    n_reg=2,
    decoder=_decode_2reg,
    source_dest_regs=([1], [0]),
)
class InsLeadingZeroBits32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = cast_32(regs[ra])
        regs[rd] = 32 - v.bit_length() if v != 0 else 32


@instr(
    105,
    "trailing_zero_bits_64",
    n_reg=2,
    decoder=_decode_2reg,
    source_dest_regs=([1], [0]),
)
class InsTrailingZeroBits64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = regs[ra] & ((1 << 64) - 1)
        regs[rd] = (v & -v).bit_length() - 1 if v != 0 else 64


@instr(
    106,
    "trailing_zero_bits_32",
    n_reg=2,
    decoder=_decode_2reg,
    source_dest_regs=([1], [0]),
)
class InsTrailingZeroBits32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = cast_32(regs[ra])
        regs[rd] = (v & -v).bit_length() - 1 if v != 0 else 32


@instr(107, "sign_extend_8", n_reg=2, decoder=_decode_2reg, source_dest_regs=([1], [0]))
class InsSignExtend8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = zeta_inv(8, zeta(1, cast_8(regs[ra])))


@instr(
    108, "sign_extend_16", n_reg=2, decoder=_decode_2reg, source_dest_regs=([1], [0])
)
class InsSignExtend16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = zeta_inv(8, zeta(2, cast_16(regs[ra])))


@instr(
    109, "zero_extend_16", n_reg=2, decoder=_decode_2reg, source_dest_regs=([1], [0])
)
class InsZeroExtend16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = cast_16(regs[ra])


@instr(110, "reverse_bytes", n_reg=2, decoder=_decode_2reg, source_dest_regs=([1], [0]))
class InsReverseBytes(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = int.from_bytes(
            regs[ra].to_bytes(length=8, byteorder="big")[::-1], byteorder="big"
        )


# $(0.8.0 - A.31)
INSTR_2REG_LIST = [
    InsMoveReg,
    InsCountSetBits64,
    InsCountSetBits32,
    InsLeadingZeroBits64,
    InsLeadingZeroBits32,
    InsTrailingZeroBits64,
    InsTrailingZeroBits32,
    InsSignExtend8,
    InsSignExtend16,
    InsZeroExtend16,
    InsReverseBytes,
]
