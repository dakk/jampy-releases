# Copyright (C) 2024-2026 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List

from ..pvmstate import Memory
from ..utils import cast_32
from .instr import Instr, _decode_2reg_2imm, instr


@instr(
    180,
    "load_imm_jump_ind",
    n_reg=2,
    n_imm=2,
    decoder=_decode_2reg_2imm,
    source_dest_regs=([1], [0]),
)
class InsLoadImmJumpInd(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx, vy = args

        res, pc = prog.djump(pc, cast_32(regs[rb] + vy % mem.size))
        regs[ra] = vx

        return res, None, pc


# $(0.8.0 - A.34)
INSTR_2REG_2IMM_LIST = [InsLoadImmJumpInd]
