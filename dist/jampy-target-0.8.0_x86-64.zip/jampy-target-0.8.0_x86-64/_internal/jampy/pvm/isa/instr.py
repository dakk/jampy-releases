# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from collections.abc import Callable
from functools import cached_property
from typing import Any, Optional

from jampy.codec.decode import dnat_l

from ..memory import Memory
from ..program import Program
from ..pvmstate import PVMExitReasonConstants
from ..utils import signed_extension_function, zeta


class Instr:
    """Parent class describing an ISA instruction"""

    def __init__(
        self,
        opcode: int,
        name: str,
        n_reg: int = 0,
        n_imm: int = 0,
        n_off: int = 0,
        decoder: Callable = lambda x: x,
        source_dest_regs: tuple[list[int], list[int]] = ([], []),
    ):
        self.opcode = opcode
        self.name = name
        self.n_reg = n_reg
        self.n_imm = n_imm
        self.n_off = n_off
        self.decoder = decoder
        self.source_dest_regs = source_dest_regs

    def __repr__(self) -> str:
        return self.name

    @cached_property
    def arity(self) -> tuple[int, int, int]:
        return (self.n_reg, self.n_imm, self.n_off)

    @staticmethod
    def exec(
        pc: int, regs: list[int], mem: Memory, prog: Program, args: Any
    ) -> Optional[tuple[PVMExitReasonConstants, Optional[int], int]]:
        raise NotImplementedError("Abstract Instr.exec")


def instr(
    opcode: int,
    name: str,
    n_reg: int = 0,
    n_imm: int = 0,
    n_off: int = 0,
    decoder: Optional[Callable] = None,
    source_dest_regs: tuple[list[int], list[int]] = ([], []),
) -> Callable:
    def decorator(cls: Any) -> Any:
        class InstrWrapper(cls):  # type: ignore
            def __init__(self) -> None:
                super().__init__(
                    opcode, name, n_reg, n_imm, n_off, decoder, source_dest_regs
                )

        return InstrWrapper

    return decorator


# Inlined min(4, max(0, elle - 1))
def min4_max0(v: int) -> int:
    return 0 if v < 0 else min(v, 4)


def _decode_3reg(c_extended: memoryview, pc: int, elle: int) -> tuple[int, int, int]:
    c_1 = c_extended[pc + 1]
    ra = c_1 & 0xF
    rb = c_1 >> 4
    rd = c_extended[pc + 2]
    return ra % 13, rb % 13, rd % 13


def _decode_2reg_1imm(
    c_extended: memoryview, pc: int, elle: int
) -> tuple[int, int, int]:
    c_1 = c_extended[pc + 1]
    ra = c_1 & 0xF
    rb = c_1 >> 4
    l_x = min4_max0(elle - 1)
    vx = signed_extension_function(l_x, dnat_l(l_x, c_extended, pc + 2))
    return ra % 13, rb % 13, vx


def _decode_1reg_1imm(c_extended: memoryview, pc: int, elle: int) -> tuple[int, int]:
    ra = c_extended[pc + 1] & 0xF
    l_x = min4_max0(elle - 1)
    vx = signed_extension_function(l_x, dnat_l(l_x, c_extended, pc + 2))
    return ra % 13, vx


def _decode_1reg_1imm_load_imm_64(
    c_extended: memoryview, pc: int, elle: int
) -> tuple[int, int]:
    ra = c_extended[pc + 1] & 0xF
    vx = dnat_l(8, c_extended, pc + 2)
    return ra % 13, vx


def _decode_2reg(c_extended: memoryview, pc: int, elle: int) -> tuple[int, int]:
    c_1 = c_extended[pc + 1]
    rd = c_1 & 0xF
    ra = c_1 >> 4
    return rd % 13, ra % 13


def _decode_1reg_1imm_1off(
    c_extended: memoryview, pc: int, elle: int
) -> tuple[int, int, int]:
    c_1 = c_extended[pc + 1]
    ra = c_1 & 0xF
    l_x = min(4, (c_1 >> 4) % 8)
    l_y = min4_max0(elle - l_x - 1)
    vx = signed_extension_function(l_x, dnat_l(l_x, c_extended, pc + 2))
    vy = pc + zeta(l_y, dnat_l(l_y, c_extended, pc + 2 + l_x))
    return ra % 13, vx, vy


def _decode_2reg_1off(
    c_extended: memoryview, pc: int, elle: int
) -> tuple[int, int, int]:
    c_1 = c_extended[pc + 1]
    ra = c_1 & 0xF
    rb = c_1 >> 4
    l_x = min4_max0(elle - 1)
    vx = pc + signed_extension_function(l_x, dnat_l(l_x, c_extended, pc + 2))
    return ra % 13, rb % 13, vx


def _decode_1reg_2imm(
    c_extended: memoryview, pc: int, elle: int
) -> tuple[int, int, int]:
    c_1 = c_extended[pc + 1]
    ra = c_1 & 0xF
    l_x = min(4, c_1 >> 4 % 8)
    l_y = min4_max0(elle - l_x - 1)
    vx = signed_extension_function(l_x, dnat_l(l_x, c_extended, pc + 2))
    vy = signed_extension_function(l_y, dnat_l(l_y, c_extended, pc + 2 + l_x))
    return ra % 13, vx, vy


def _decode_2imm(c_extended: memoryview, pc: int, elle: int) -> tuple[int, int]:
    "$(0.8.0 - A.26)"
    l_x = min(4, c_extended[pc + 1] % 8)
    l_y = min4_max0(elle - l_x - 1)
    vx = signed_extension_function(l_x, dnat_l(l_x, c_extended, pc + 2))
    vy = signed_extension_function(l_y, dnat_l(l_y, c_extended, pc + 2 + l_x))
    return vx, vy


def _decode_none(c_extended: memoryview, pc: int, elle: int) -> None:
    return


def _decode_1imm(c_extended: memoryview, pc: int, elle: int) -> int:
    l_x = min(4, elle)
    vx = signed_extension_function(l_x, dnat_l(l_x, c_extended, pc + 1))
    return vx


def _decode_1off(c_extended: memoryview, pc: int, elle: int) -> int:
    l_x = min(4, elle)
    vx = pc + zeta(l_x, dnat_l(l_x, c_extended, pc + 1))
    return vx


def _decode_2reg_2imm(
    c_extended: memoryview, pc: int, elle: int
) -> tuple[int, int, int, int]:
    c_1 = c_extended[pc + 1]
    ra = c_1 & 0xF
    rb = c_1 >> 4
    l_x = min(4, c_extended[pc + 2] % 8)
    l_y = min4_max0(elle - l_x - 2)
    vx = signed_extension_function(l_x, dnat_l(l_x, c_extended, pc + 3))
    vy = signed_extension_function(l_y, dnat_l(l_y, c_extended, pc + 3 + l_x))
    return ra % 13, rb % 13, vx, vy
