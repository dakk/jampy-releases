# Copyright (C) 2024-2026 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List

from ..pvmstate import Memory, PVMExitReasonConstants
from .instr import Instr, _decode_none, instr

INS_TRAP_OPCODE = 0
INS_UNKLIKELY_OPCODE = 2


@instr(0, "trap", decoder=_decode_none)
class InsTrap(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        return PVMExitReasonConstants.PANIC, None, pc


@instr(1, "fallthrough", decoder=_decode_none)
class InsFallthrough(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        res, pc = prog.sjump(pc, pc + 1 + prog.skip(pc))
        return res, None, pc


@instr(2, "unlikely", decoder=_decode_none)
class InsUnlikely(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        return PVMExitReasonConstants.CONTINUE, None, pc


# $(0.8.0 - A.23)
INSTR_NOARG_LIST = [InsTrap, InsFallthrough, InsUnlikely]
