# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

from __future__ import annotations

import json


class JSONDecodeError(Exception):
    def __init__(self, *args):  # type: ignore[no-untyped-def]
        super().__init__(*args)


class Serializable:
    @staticmethod
    def from_bytes(b: bytes) -> tuple[Serializable, bytes]:
        raise NotImplementedError("Abstract")

    def to_bytes(self) -> bytes:
        raise NotImplementedError("Abstract")


class JSONSerializable:
    @staticmethod
    def from_json(b: dict) -> JSONSerializable:
        raise NotImplementedError("Abstract: JSONSerializable.from_json")

    @classmethod
    def from_json_file(cls, jfile: str) -> JSONSerializable:
        with open(jfile, "r") as f:
            jdata = json.loads(f.read())
        return cls.from_json(jdata)

    def to_json(self) -> dict:
        raise NotImplementedError("Abstract: JSONSerializable.to_json")
