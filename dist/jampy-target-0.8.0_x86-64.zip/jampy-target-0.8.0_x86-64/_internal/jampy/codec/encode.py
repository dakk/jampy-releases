# Copyright (C) 2024-2026 Davide Gessa
# This file is part of Jampy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

import math
from collections.abc import Sequence
from decimal import Decimal
from functools import reduce
from operator import add
from typing import Any, Optional


class EncodeError(Exception):
    def __init__(self, *args):  # type: ignore[no-untyped-def]
        super().__init__(*args)


def i2b(length: int, x: int) -> bytes:
    return int.to_bytes(x, length=length, byteorder="little", signed=False)


class Encoder:
    """Encoder implementing E(x) (0.4.5 - Appendix C)"""

    @staticmethod
    def encode_void() -> bytes:
        "Encode void $(0.8.0 - C.1)"
        return b""

    @staticmethod
    def encode_octet(b: bytes) -> bytes:
        "Encode octet $(0.8.0 - C.2)"
        return b

    @staticmethod
    def encode_tuple(t: tuple) -> bytes:
        "Encode tuple $(0.8.0 - C.3)"
        return reduce(add, (Encoder.encode(v) for v in t), b"")

    @staticmethod
    def encode_args(*args) -> bytes:  # type: ignore[no-untyped-def]
        "Encode args $(0.8.0 - C.4)"
        return Encoder.encode_tuple(args)

    @staticmethod
    def encode_nat_l(l: int, x: int) -> bytes:
        "Encoding natural number, little-endian $(0.8.0 - C.12 / C.13 / C.14 / C.15)"
        return i2b(l, x)

    @staticmethod
    def encode_nat(x: int) -> bytes:
        "General nat encoding $(0.8.0 - C.5)"
        if x == 0:
            return bytes([0])

        # Find an l in N8 | 2**(7*l) <= x < 2**(7*(l+1))
        def find_l(l: int = 0) -> Optional[int]:
            if l >= 8:
                return None
            if x >= (2 ** (7 * l)) and x < 2 ** (7 * (l + 1)):
                return l
            else:
                return find_l(l + 1)

        l = find_l()

        if l is None and x < 2**64:
            return i2b(1, 2**8 - 1) + Encoder.encode_nat_l(8, x)
        elif l is None:
            raise EncodeError(f"l is None, x is {x}")

        return i2b(
            1, 2**8 - 2 ** (8 - l) + math.floor(Decimal(x) / Decimal(2 ** (8 * l)))
        ) + Encoder.encode_nat_l(l, x % (2 ** (8 * l)))

    @staticmethod
    def encode_sequence(s: Sequence) -> bytes:
        "Encode sequence $(0.8.0 - C.6)"
        return Encoder.encode_args(*s)

    @staticmethod
    def encode_set(s: set) -> bytes:
        "Encode set $(0.8.0 - C.11)"
        return Encoder.encode_tuple(tuple(s))

    @staticmethod
    def encode_variable_size(v: Any) -> bytes:
        "Encode variable size (of bytes)  $(0.8.0 - C.7)"
        v_enc = Encoder.encode(v)
        return Encoder.encode_nat(len(v_enc)) + v_enc

    @staticmethod
    def encode_optional(v: Any) -> bytes:
        "Encode optional value $(0.8.0 - C.8)"
        v_enc = Encoder.encode(v)
        if v is None or len(v) == 0:
            return bytes([0])
        return Encoder.encode_tuple((i2b(1, 1), v_enc))

    @staticmethod
    def encode_bit_sequence(b: list[bool]) -> bytes:
        "Encode bit sequence $(0.8.0 - C.9)"
        if not b:
            return b""
        n = len(b)
        byte_size = (n + 7) >> 3
        result = bytearray(byte_size)
        for byte_idx in range(byte_size):
            bv = 0
            for i, bit in enumerate(b[byte_idx * 8 : (byte_idx + 1) * 8]):
                if bit:
                    bv |= 1 << i
            result[byte_idx] = bv
        return bytes(result)

    @staticmethod
    def encode_dict(d: dict[Any, Any]) -> bytes:
        "Dictionary encoding $(0.8.0 - C.10)"
        raise Exception("Don't use")

        d_enc = {}

        for k, v in d.items():
            d_enc[Encoder.encode(k)] = Encoder.encode(v)

        res = b""

        k_enc = list(d_enc.keys())
        k_enc.sort()
        for k in k_enc:
            res += k + d_enc[k]

        return Encoder.encode_variable_size(res)

    @staticmethod
    def encode_list(l: list, sized: bool) -> bytes:
        b = b""

        if sized:
            b += Encoder.encode_nat(len(l))

        for i in l:
            b += i.to_bytes()

        return b

    @staticmethod
    def encode(v: Any) -> bytes:
        match v:
            case int():
                return Encoder.encode_nat(v)
            case bytes():
                return Encoder.encode_octet(v)
            case dict():
                return Encoder.encode_dict(v)
            case tuple():
                return Encoder.encode_tuple(v)
            case set():
                return Encoder.encode_set(v)
            case list():
                if all(type(e) is bool for e in v):
                    return Encoder.encode_bit_sequence(v)
                return Encoder.encode_sequence(v)
            case _:
                return Encoder.encode_void()


def encode(v: Any) -> bytes:
    return Encoder.encode(v)
