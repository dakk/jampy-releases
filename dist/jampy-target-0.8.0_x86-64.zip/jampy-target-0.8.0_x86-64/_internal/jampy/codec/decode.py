# Copyright (C) 2024-2026 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Any, Dict, List, Optional, Sequence, Set, Tuple, Union


class DecodeError(Exception):
    def __init__(self, *args):
        super().__init__(*args)


def b2i(x: Union[int, bytes]) -> int:
    if type(x) is int:
        return b2i(bytes([x]))
    elif type(x) is bytes:
        return int.from_bytes(x, byteorder="little", signed=False)

    raise DecodeError()


def dnat_l_no_offset(l: int, b: bytes | memoryview) -> int:
    "decode_nat_l inlined: decode l bytes int from b"
    if l == 0:
        return 0
    elif l == 1:
        return b[0]
    elif l == 2:
        return b[0] | (b[1] << 8)
    elif l == 4:
        return b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)
    elif l == 8:
        return (
            b[0]
            | (b[1] << 8)
            | (b[2] << 16)
            | (b[3] << 24)
            | (b[4] << 32)
            | (b[5] << 40)
            | (b[6] << 48)
            | (b[7] << 56)
        )
    else:
        val = 0
        for i in range(l):
            val |= b[i] << (8 * i)
        return val


def dnat_l(l: int, b: bytes | memoryview, o: int) -> int:
    "decode_nat_l inlined: decode l bytes int from b starting at offset o"
    if l == 0:
        return 0
    elif l == 1:
        return b[o]
    elif l == 2:
        return b[o] | (b[o + 1] << 8)
    elif l == 4:
        return b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)
    elif l == 8:
        return (
            b[o]
            | (b[o + 1] << 8)
            | (b[o + 2] << 16)
            | (b[o + 3] << 24)
            | (b[o + 4] << 32)
            | (b[o + 5] << 40)
            | (b[o + 6] << 48)
            | (b[o + 7] << 56)
        )
    else:
        val = 0
        for i in range(l):
            val |= b[o + i] << (8 * i)
        return val


class Decoder:
    """Decoder implementing E**-1(x) (0.4.5 - Appendix C)"""

    @staticmethod
    def decode_void(b: bytes) -> Tuple[None, bytes]:
        return (None, b)

    @staticmethod
    def decode_octet(b: bytes) -> Tuple[bytes, bytes]:
        return (b, bytes())

    @staticmethod
    def decode_tuple(b: bytes) -> Tuple[Tuple, bytes]:
        tup = []
        while len(b) > 0:
            v, b = Decoder.decode(b)
            tup.append(v)
        return tuple(tup), b

    @staticmethod
    def decode_set(b: bytes) -> Tuple[Set, bytes]:
        tup = []
        while len(b) > 0:
            v, b = Decoder.decode(b)
            tup.append(v)
        return set(tup), b

    @staticmethod
    def decode_sequence(b: bytes) -> Tuple[Sequence, bytes]:
        return Decoder.decode_tuple(b)

    # Decoding natural number, little-endian
    @staticmethod
    def decode_nat_l(l: int, b: bytes | memoryview, unsafe=False) -> Tuple[int, bytes]:
        if len(b) < l and not unsafe:
            raise DecodeError(
                f"No enough bytes for decode_nat_l {len(b)} (expected: {l})"
            )
        return int.from_bytes(b[:l], byteorder="little", signed=False), b[l:]  # type: ignore
        # return b2i(b[:l]), b[l:]

    # General nat decoding
    @staticmethod
    def decode_nat(b: bytes) -> Tuple[int, bytes]:  # type: ignore
        if b[0] == 0:
            return 0, b[1:]
        elif b[0] == 0xFF:
            return Decoder.decode_nat_l(8, b[1:])

        first_byte = b[0]
        l = 0
        while first_byte & 0b10000000:
            l += 1
            first_byte <<= 1

        v_high = (b[0] - (2**8 - 2 ** (8 - l))) * (2 ** (8 * l))
        v_low, rest = Decoder.decode_nat_l(l, b[1:])
        return v_high + v_low, rest

    # Decode variable size (of bytes, not as intended by the paper)
    @staticmethod
    def decode_variable_size(b: bytes) -> Tuple[Any, bytes]:  # type: ignore
        size, rest = Decoder.decode_nat(b)
        return rest[:size], rest[size:]

    @staticmethod
    def decode_optional(b: bytes) -> Tuple[Optional[Any], bytes]:  # type: ignore
        if b[0] == 0:
            return None, b[1:]
        elif b[0] != 0x01:
            raise DecodeError()

        return b[1:], bytes()

    @staticmethod
    def decode_bit_sequence(n: int, b: bytes) -> Tuple[List[bool], bytes]:
        byte_size = (n + 7) >> 3
        num = int.from_bytes(b[:byte_size], "little")
        return [bool(num & (1 << i)) for i in range(n)], b[byte_size:]

    @staticmethod
    def decode_dict(b: bytes) -> Tuple[Dict[Any, Any], bytes]:  # type: ignore
        raise NotImplementedError()

    @staticmethod
    def decode_list(cls, n: Optional[int], b: bytes):
        if n is None:
            n, b = Decoder.decode_nat(b)

        vv = []
        for i in range(n):
            v, b = cls.from_bytes(b)
            vv.append(v)
        return vv, b

    @staticmethod
    def decode(b: bytes) -> Tuple[Any, bytes]:  # type: ignore
        # This can't be implemented without knowing the structure of the binary
        pass


def decode(b: bytes) -> Any:
    return Decoder.decode(b)[0]
