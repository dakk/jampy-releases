# Copyright (C) 2024-2025 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List

from ..pvmstate import Memory
from ..utils import cast_8, cast_16, cast_32, zeta, zeta_inv
from .instr import Instr, _decode_2reg, instr


@instr(100, "move_reg", n_reg=2, decoder=_decode_2reg)
class InsMoveReg(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = regs[ra]


@instr(101, "sbrk", n_reg=2, decoder=_decode_2reg)
class InsSbrk(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args

        size = regs[ra]
        min_v = None

        # TODO: this is not yet in line with gp maybe?
        # https://paritytech.github.io/matrix-archiver/archive/
        # _21ddsEwXlCWnreEGuqXZ_3Apolkadot.io/index.html#
        # $_RkIlMDNZrROw_6WDXpbllO2VSbjY1FNTIfDjVZhhdw

        # x = mem.heap
        # while min_v is None:
        #     if mem.is_writable(x, size): #not mem.is_readable(x, size):
        #         min_v = x
        #     x += 1

        #     if x > mem.size:
        #         raise Exception("Sbrk failed")
        min_v = mem.heap

        mem.accset(min_v, size, w=True)

        mem.heap = min_v + size
        regs[rd] = min_v


@instr(102, "count_set_bits_64", n_reg=2, decoder=_decode_2reg)
class InsCountSetBits64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = regs[ra] & ((1 << 64) - 1)  # ensure 64-bit
        regs[rd] = regs[ra].bit_count()


@instr(103, "count_set_bits_32", n_reg=2, decoder=_decode_2reg)
class InsCountSetBits32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = cast_32(regs[ra])
        regs[rd] = v.bit_count()


@instr(104, "leading_zero_bits_64", n_reg=2, decoder=_decode_2reg)
class InsLeadingZeroBits64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = regs[ra] & ((1 << 64) - 1)
        regs[rd] = 64 - v.bit_length() if v != 0 else 64


@instr(105, "leading_zero_bits_32", n_reg=2, decoder=_decode_2reg)
class InsLeadingZeroBits32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = cast_32(regs[ra])
        regs[rd] = 32 - v.bit_length() if v != 0 else 32


@instr(106, "trailing_zero_bits_64", n_reg=2, decoder=_decode_2reg)
class InsTrailingZeroBits64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = regs[ra] & ((1 << 64) - 1)
        regs[rd] = (v & -v).bit_length() - 1 if v != 0 else 64


@instr(107, "trailing_zero_bits_32", n_reg=2, decoder=_decode_2reg)
class InsTrailingZeroBits32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        v = cast_32(regs[ra])
        regs[rd] = (v & -v).bit_length() - 1 if v != 0 else 32


@instr(108, "sign_extend_8", n_reg=2, decoder=_decode_2reg)
class InsSignExtend8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = zeta_inv(8, zeta(1, cast_8(regs[ra])))


@instr(109, "sign_extend_16", n_reg=2, decoder=_decode_2reg)
class InsSignExtend16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = zeta_inv(8, zeta(2, cast_16(regs[ra])))


@instr(110, "zero_extend_16", n_reg=2, decoder=_decode_2reg)
class InsZeroExtend16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = cast_16(regs[ra])


@instr(111, "reverse_bytes", n_reg=2, decoder=_decode_2reg)
class InsReverseBytes(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        rd, ra = args
        regs[rd] = int.from_bytes(
            regs[ra].to_bytes(length=8, byteorder="big")[::-1], byteorder="big"
        )


# $(0.7.1 - A.28)
INSTR_2REG_LIST = [
    InsMoveReg,
    InsSbrk,
    InsCountSetBits64,
    InsCountSetBits32,
    InsLeadingZeroBits64,
    InsLeadingZeroBits32,
    InsTrailingZeroBits64,
    InsTrailingZeroBits32,
    InsSignExtend8,
    InsSignExtend16,
    InsZeroExtend16,
    InsReverseBytes,
]
