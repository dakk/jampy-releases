# Copyright (C) 2024-2025 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from math import floor
from typing import List

from jampy.codec import dnat_l_no_offset, i2b

from ..pvmstate import Memory
from ..utils import (
    bw_and,
    bw_or,
    bw_xor,
    cast_8,
    cast_16,
    cast_32,
    cast_64,
    rot_r,
    signed_extension_function,
    zeta,
    zeta_inv,
)
from .instr import Instr, _decode_2reg_1imm, instr


@instr(120, "store_ind_u8", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsStoreIndU8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        mem[regs[rb] + vx] = cast_8(regs[ra])


@instr(121, "store_ind_u16", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsStoreIndU16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        mem.memcpy(regs[rb] + vx, i2b(2, cast_16(regs[ra])))


@instr(122, "store_ind_u32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsStoreIndU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        mem.memcpy(regs[rb] + vx, i2b(4, cast_32(regs[ra])))


@instr(123, "store_ind_u64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsStoreIndU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        mem.memcpy(regs[rb] + vx, i2b(8, regs[ra]))


@instr(124, "load_ind_u8", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsLoadIndU8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = mem[regs[rb] + vx]


@instr(125, "load_ind_i8", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsLoadIndI8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = zeta_inv(8, zeta(1, mem[regs[rb] + vx]))


@instr(126, "load_ind_u16", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsLoadIndU16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = dnat_l_no_offset(2, mem.get(regs[rb] + vx, 2))


@instr(127, "load_ind_i16", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsLoadIndI16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = zeta_inv(8, zeta(2, dnat_l_no_offset(2, mem.get(regs[rb] + vx, 2))))


@instr(128, "load_ind_u32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsLoadIndU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = dnat_l_no_offset(4, mem.get(regs[rb] + vx, 4))


@instr(129, "load_ind_i32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsLoadIndI32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = zeta_inv(8, zeta(4, dnat_l_no_offset(4, mem.get(regs[rb] + vx, 4))))


@instr(130, "load_ind_u64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsLoadIndU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = dnat_l_no_offset(8, mem.get(regs[rb] + vx, 8))


@instr(131, "add_imm_32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsAddImm32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(4, cast_32(regs[rb] + vx))


@instr(132, "and_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsAndImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = bw_and(regs[rb], vx)


@instr(133, "xor_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsXorImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = bw_xor(regs[rb], vx)


@instr(134, "or_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsOrImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = bw_or(regs[rb], vx)


@instr(135, "mul_imm_32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsMulImm32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(4, cast_32(regs[rb] * vx))


@instr(136, "set_lt_u_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsSetLtUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = int(regs[rb] < vx)


@instr(137, "set_lt_s_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsSetLtSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = int(zeta(8, regs[rb]) < zeta(8, vx))


@instr(138, "shlo_l_imm_32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsShloLImm32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(4, cast_32(regs[rb] * 2 ** (vx % 32)))


@instr(139, "shlo_r_imm_32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsShloRImm32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(
            4, floor(cast_32(regs[rb]) // 2 ** (vx % 32))
        )


@instr(140, "shar_r_imm_32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsSharRImm32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = zeta_inv(8, floor(zeta(4, cast_32(regs[rb])) // 2 ** (vx % 32)))


@instr(141, "neg_add_imm_32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsNegAddImm32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(4, cast_32(vx + 2**32 - regs[rb]))


@instr(142, "set_gt_u_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsSetGtUImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = int(regs[rb] > vx)


@instr(143, "set_gt_s_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsSetGtSImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = int(zeta(8, regs[rb]) > zeta(8, vx))


@instr(144, "shlo_l_imm_alt_32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsShloLImmAlt32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(4, cast_32(vx * 2 ** (regs[rb] % 32)))


@instr(145, "shlo_r_imm_alt_32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsShloRImmAlt32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(
            4, floor(cast_32(vx) // 2 ** (regs[rb] % 32))
        )


@instr(146, "shar_r_imm_alt_32", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsSharRImmAlt32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = zeta_inv(8, (zeta(4, cast_32(vx)) // 2 ** (regs[rb] % 32)))


@instr(147, "cmov_iz_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsCmovIzImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[rb] == 0:
            regs[ra] = vx


@instr(148, "cmov_nz_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsCmovNzImm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        if regs[rb] != 0:
            regs[ra] = vx


@instr(149, "add_imm_64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsAddImm64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = cast_64(regs[rb] + vx)


@instr(150, "mul_imm_64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsMulImm64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = cast_64(regs[rb] * vx)


@instr(151, "shlo_l_imm_64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsShloLImm64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(8, cast_64(regs[rb] * 2 ** (vx % 64)))


@instr(152, "shlo_r_imm_64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsShloRImm64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(8, floor(regs[rb] // 2 ** (vx % 64)))


@instr(153, "shar_r_imm_64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsSharRImm64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = zeta_inv(8, floor(zeta(8, regs[rb]) // 2 ** (vx % 64)))


@instr(154, "neg_add_imm_64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsNegAddImm64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = cast_64(vx + 2**64 - regs[rb])


@instr(155, "shlo_l_imm_alt_64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsShloLImmAlt64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = cast_64(vx * 2 ** (regs[rb] % 64))


@instr(156, "shlo_r_imm_alt_64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsShloRImmAlt64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = floor(vx // 2 ** (regs[rb] % 64))


@instr(157, "shar_r_imm_alt_64", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsSharRImmAlt64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = zeta_inv(8, floor(zeta(8, vx) // 2 ** (regs[rb] % 64)))


@instr(158, "rot_r_64_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsRotR64Imm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = rot_r(8, regs[rb], vx)


@instr(159, "rot_r_64_imm_alt", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsRotR64ImmAlt(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = rot_r(8, vx, regs[rb])


@instr(160, "rot_r_32_imm", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsRotR32Imm(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(4, rot_r(4, regs[rb], vx))


@instr(161, "rot_r_32_imm_alt", n_reg=2, n_imm=1, decoder=_decode_2reg_1imm)
class InsRotR32ImmAlt(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, rb, vx = args
        regs[ra] = signed_extension_function(4, rot_r(4, vx, regs[rb]))


# $(0.7.1 - A.29)
INSTR_2REG_1IMM_LIST = [
    InsStoreIndU8,
    InsStoreIndU16,
    InsStoreIndU32,
    InsStoreIndU64,
    InsLoadIndU8,
    InsLoadIndI8,
    InsLoadIndU16,
    InsLoadIndI16,
    InsLoadIndU32,
    InsLoadIndI32,
    InsLoadIndU64,
    InsAddImm32,
    InsAndImm,
    InsXorImm,
    InsOrImm,
    InsMulImm32,
    InsSetLtUImm,
    InsSetLtSImm,
    InsShloLImm32,
    InsShloRImm32,
    InsSharRImm32,
    InsNegAddImm32,
    InsSetGtUImm,
    InsSetGtSImm,
    InsShloLImmAlt32,
    InsShloRImmAlt32,
    InsSharRImmAlt32,
    InsCmovIzImm,
    InsCmovNzImm,
    InsAddImm64,
    InsMulImm64,
    InsShloLImm64,
    InsShloRImm64,
    InsSharRImm64,
    InsNegAddImm64,
    InsShloLImmAlt64,
    InsShloRImmAlt64,
    InsSharRImmAlt64,
    InsRotR32Imm,
    InsRotR32ImmAlt,
    InsRotR64Imm,
    InsRotR64ImmAlt,
]
