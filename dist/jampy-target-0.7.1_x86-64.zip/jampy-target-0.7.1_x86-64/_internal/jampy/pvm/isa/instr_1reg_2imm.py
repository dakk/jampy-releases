# Copyright (C) 2024-2025 Davide Gessa

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import List

from jampy.codec import i2b

from ..pvmstate import Memory
from ..utils import cast_8, cast_16, cast_32
from .instr import Instr, _decode_1reg_2imm, instr


@instr(70, "store_imm_ind_u8", n_reg=1, n_imm=2, decoder=_decode_1reg_2imm)
class InsStoreImmIndU8(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        mem[regs[ra] + vx] = cast_8(vy)


@instr(71, "store_imm_ind_u16", n_reg=1, n_imm=2, decoder=_decode_1reg_2imm)
class InsStoreImmIndU16(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        mem.memcpy(regs[ra] + vx, i2b(2, cast_16(vy)))


@instr(72, "store_imm_ind_u32", n_reg=1, n_imm=2, decoder=_decode_1reg_2imm)
class InsStoreImmIndU32(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        mem.memcpy(regs[ra] + vx, i2b(4, cast_32(vy)))


@instr(73, "store_imm_ind_u64", n_reg=1, n_imm=2, decoder=_decode_1reg_2imm)
class InsStoreImmIndU64(Instr):
    @staticmethod
    def exec(pc: int, regs: List[int], mem: Memory, prog, args):
        ra, vx, vy = args
        mem.memcpy(regs[ra] + vx, i2b(8, vy))


# $(0.7.1 - A.26)
INSTR_1REG_2IMM_LIST = [
    InsStoreImmIndU8,
    InsStoreImmIndU16,
    InsStoreImmIndU32,
    InsStoreImmIndU64,
]
